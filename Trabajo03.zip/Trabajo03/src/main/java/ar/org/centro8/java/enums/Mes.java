package ar.org.centro8.java.enums;

public enum Mes {

    ENE,
    FEB,
    MAR,
    ABR,
    MAY,
    JUN,
    JUL,
    SEPT,
    OCT,
    NOV,
    DIC

}
