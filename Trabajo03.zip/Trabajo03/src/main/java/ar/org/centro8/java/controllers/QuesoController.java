package ar.org.centro8.java.controllers;

import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.java.entities.Queso;
import ar.org.centro8.java.enums.Dia;
import ar.org.centro8.java.enums.Mes;
import ar.org.centro8.java.repositories.QuesoRepository;

@Controller
public class QuesoController {

    private String mensaje="Ingrese un nuevo tipo!";
    private QuesoRepository quesoRepository = new QuesoRepository();

    @GetMapping("/quesos")
    public String getQueso(Model model, @RequestParam(name = "buscar",defaultValue = "")String buscar) {
        model.addAttribute("dias", Arrays.asList(Dia.values()));
        model.addAttribute("meses", Arrays.asList(Mes.values()));
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("queso", new Queso());
        model.addAttribute("likeTipo", quesoRepository.getLikeTipo(buscar));
        return "quesos";
        
    }

    @PostMapping("/quesoSave")
    public String quesoSave(@ModelAttribute Queso queso) {
        quesoRepository.save(queso);
        if(queso.getId()>0){
            mensaje="Se guardo el queso id: "+queso.getId();
        }else{
            mensaje="Error! No se pudo guardar el queso!";
        }
        return "redirect:quesos";

    }
}
