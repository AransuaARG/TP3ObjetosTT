package ar.org.centro8.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.java.connectors.Connector;
import ar.org.centro8.java.entities.Empleado;

public class EmpleadoRepository {

    private Connection conn=Connector.getConnection();

    public void save(Empleado empleado){
        if(empleado==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into empleados (nombre, apellido, edad, idQueso) values (?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, empleado.getNombre());
            ps.setString(2, empleado.getApellido());
            ps.setInt(3, empleado.getEdad());
            ps.setInt(4, empleado.getIdQueso());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) empleado.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Empleado empleado){
        if(empleado==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "delete from empleados where id=?")){
            ps.setInt(1, empleado.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Empleado>getAll(){
        List<Empleado> list=new ArrayList();
        try (ResultSet rs=conn
                .createStatement()
                .executeQuery("select * from empleados")){
            while(rs.next()){
                list.add(new Empleado(
                    rs.getInt("id"), 
                    rs.getString("nombre"), 
                    rs.getString("apellido"), 
                    rs.getInt("edad"), 
                    rs.getInt("idQueso")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Empleado getById(int id){
        return getAll()
            .stream()
            .filter(empleado->empleado.getId()==id)
            .findFirst()
            .orElse(new Empleado());
    }

    public List<Empleado>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(empleado->empleado
                .getApellido()
                .toLowerCase()
                .contains(apellido.toLowerCase()))
            .toList();
    }

}
