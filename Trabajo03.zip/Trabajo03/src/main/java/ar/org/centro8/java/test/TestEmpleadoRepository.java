package ar.org.centro8.java.test;

import ar.org.centro8.java.entities.Empleado;
import ar.org.centro8.java.repositories.EmpleadoRepository;

public class TestEmpleadoRepository {
    public static void main(String[] args) {
        EmpleadoRepository empleadoRepository = new EmpleadoRepository();

        Empleado empleado = new Empleado(
            0,
            "Julio",
            "Gomez",
            55,
            1);
        empleadoRepository.save(empleado);
        System.out.println(empleado);

        System.out.println(empleadoRepository.getById(8));

        empleadoRepository.remove(empleadoRepository.getById(9));

        empleadoRepository.getLikeApellido("go").forEach(System.out::println);

        empleadoRepository.getAll().forEach(System.out::println);
    }
}
