package ar.org.centro8.java.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.java.entities.Empleado;
import ar.org.centro8.java.repositories.EmpleadoRepository;
import ar.org.centro8.java.repositories.QuesoRepository;

@Controller
public class EmpleadoController {
    
    private String mensaje="Ingrese un nuevo empleado!";
    private EmpleadoRepository empleadoRepository=new EmpleadoRepository();
    private QuesoRepository quesoRepository=new QuesoRepository();

    @GetMapping("/empleados")
    public String getEmpleados(Model model, @RequestParam(name = "buscar",defaultValue = "")String buscar){
        Empleado empleado=new Empleado();
        empleado.setEdad(18);
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("empleado", empleado);
        model.addAttribute("likeApellido", empleadoRepository.getLikeApellido(buscar));
        model.addAttribute("queso", quesoRepository.getAll());
        return "empleados";
    }

    @PostMapping("/empleadoSave")
    public String empleadoSave(@ModelAttribute Empleado empleado){
        empleadoRepository.save(empleado);
        if(empleado.getId()>0){
            mensaje="Se guardo el empleado id: "+empleado.getId();
        }else{
            mensaje="Error! No se pudo guardar el empleado!";
        }
        return "redirect:empleados";
    }
}
