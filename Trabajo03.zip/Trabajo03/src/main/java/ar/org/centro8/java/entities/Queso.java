package ar.org.centro8.java.entities;

import ar.org.centro8.java.enums.Dia;
import ar.org.centro8.java.enums.Mes;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Queso {
    private int id;
    private String tipo;
    private String proceso;
    private Dia dia;
    private Mes mes;
    
}
