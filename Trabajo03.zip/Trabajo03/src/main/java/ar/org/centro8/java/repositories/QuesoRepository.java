package ar.org.centro8.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.java.connectors.Connector;
import ar.org.centro8.java.entities.Queso;
import ar.org.centro8.java.enums.Dia;
import ar.org.centro8.java.enums.Mes;

public class QuesoRepository {
    private Connection conn=Connector.getConnection();

    public void save(Queso queso){
        if(queso==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "insert into quesos (tipo, proceso, dia, mes) values (?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, queso.getTipo());
            ps.setString(2, queso.getProceso());
            ps.setString(3, queso.getDia().toString());
            ps.setString(4, queso.getMes().toString());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) queso.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Queso queso){
        if(queso==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
            "delete from quesos where id=?")){
            ps.setInt(1, queso.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Queso>getAll(){
        List<Queso> list=new ArrayList();
        try (ResultSet rs=conn
                .createStatement()
                .executeQuery("select * from quesos")){
            while(rs.next()){
                list.add(new Queso(
                    rs.getInt("id"),
                    rs.getString("tipo"),
                    rs.getString("proceso"),
                    Dia.valueOf(rs.getString("dia")),
                    Mes.valueOf(rs.getString("mes"))
                    ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Queso getById(int id){
        return getAll()
            .stream()
            .filter(queso->queso.getId()==id)
            .findFirst()
            .orElse(new Queso());
    }

    public List<Queso> getLikeTipo(String tipo){
        if(tipo==null) return new ArrayList();
        return getAll()
            .stream()
            .filter(queso->queso
                .getTipo()
                .toLowerCase()
                .contains(tipo.toLowerCase()))
            .toList();
    }

}
