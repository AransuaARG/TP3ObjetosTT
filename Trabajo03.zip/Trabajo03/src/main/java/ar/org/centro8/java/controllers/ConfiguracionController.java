package ar.org.centro8.java.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.centro8.java.connectors.Connector;
import ar.org.centro8.java.utils.Properties;

@Controller
public class ConfiguracionController {
    
    @GetMapping("/configuracion")
    public String getConfiguracion(Model model){
        model.addAttribute("so", Properties.getSO());
        model.addAttribute("java", Properties.getJava());
        model.addAttribute("user", Properties.getUser());
        model.addAttribute("location", Properties.getLocation());
        model.addAttribute("ip", Properties.getIp());
        model.addAttribute("date", Properties.getDate());
        model.addAttribute("jdbc", Connector.getUrl());
        return "configuracion";
    }
}
