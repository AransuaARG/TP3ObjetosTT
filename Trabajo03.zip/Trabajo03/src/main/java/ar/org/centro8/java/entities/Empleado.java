package ar.org.centro8.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Empleado {
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int idQueso;
    
}
