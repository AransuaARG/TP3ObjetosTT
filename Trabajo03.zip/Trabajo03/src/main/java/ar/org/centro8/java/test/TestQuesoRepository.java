package ar.org.centro8.java.test;

import ar.org.centro8.java.entities.Queso;
import ar.org.centro8.java.enums.Dia;
import ar.org.centro8.java.enums.Mes;
import ar.org.centro8.java.repositories.QuesoRepository;

public class TestQuesoRepository {
    public static void main(String[] args) {
        QuesoRepository quesoRepository = new QuesoRepository();

        Queso queso = new Queso(
            0,
            "Azul",
            "prensado",
            Dia.LUNES,
            Mes.ENE);

        quesoRepository.save(queso);
        System.out.println(queso);

        System.out.println(quesoRepository.getById(5));

        quesoRepository.remove(quesoRepository.getById(6));

        quesoRepository.getLikeTipo("az").forEach(System.out::println);

        quesoRepository.getAll().forEach(System.out::println);
    }
}
