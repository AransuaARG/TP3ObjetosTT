-- Active: 1718217999723@@127.0.0.1@3306@industria
drop database if exists industria;
create database industria;
use industria;

drop table if exists empleados;
drop table if exists quesos;

create table quesos(
    id int auto_increment primary key,
    tipo varchar(20) not null check(length(tipo)>=3),
    proceso varchar(20) not null check(length(proceso)>=3),
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
    mes enum('ENE','FEB','MAR','ABR','MAY','JUN','JUL','AGO','SEPT','OCT','NOV','DIC')
);

create table empleados(
    id int auto_increment primary key,
    nombre varchar(25) not null check(length(nombre)>=3),
    apellido varchar(25) not null check(length(apellido)>=3),
    edad int not null check(edad>=18 and edad<=120),
    idQueso int not null
);

alter table empleados
    add constraint FK_Empleados_Quesos
    foreign key (idQueso) 
    references quesos(id);
