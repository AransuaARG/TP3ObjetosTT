use industria;

-- Industria del Quesos:
select * from quesos where tipo = 'fresco' order by mes;

select tipo, proceso, dia from quesos where mes = 'ABR' order by dia;

select tipo, proceso, mes from quesos where mes like 'JU%' order by mes;

select tipo, mes from quesos where proceso = "cortado" order by mes;

-- Empleados de la Industria:
select nombre, apellido, edad from empleados where edad between 30 and 49 order by nombre;

select id, apellido, edad from empleados where nombre = "Julio" order by nombre;

select id, nombre, apellido, edad from empleados where apellido like "R%" order by nombre;

select id, nombre, apellido, edad from empleados where edad > 50 order by nombre;
