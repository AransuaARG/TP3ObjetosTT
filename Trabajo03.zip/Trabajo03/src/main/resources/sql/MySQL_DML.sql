use industria;

insert into quesos (tipo, proceso, mes, anio) values
    ('fresco','coagulado','MAR',2010),
    ('curado','prensado','ENE',2010),
    ('cremoso','cortado','FEB',2012),
    ('azul','salado','OCT',2011),
    ('fresco','madurado','OCT',2012),
    ('hoja','cortado','JUL',2013),
    ('fresco','cortado','JUL',2010),
    ('cremoso','prensado','JUL',2011),
    ('pasta_hilada','coagulado','ABR',2012),
    ('azul','madurado','ABR',2013),
    ('pasta_hilada','salado','JUN',2011);

insert into empleados (nombre, apellido, edad, idQueso) values
    ('Julio','Sanches',38,1),
    ('Miguel','Alvares',45,1),
    ('Pablo','Rodriguez',62,1),
    ('Julio','Valdez',44,1),
    ('Julio','Romero',36,1),
    ('Patricia','Rodriguez',50,1),
    ('Walter','Valdez',52,1),
    ('Sebastian','Rivadavia',31,1),
    ('Federico','Valdez',68,1);
