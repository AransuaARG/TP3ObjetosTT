use industria;

insert into quesos (tipo, proceso, dia, mes) values
    ('fresco','coagulado','LUNES','MAR'),
    ('curado','prensado','MARTES','ENE'),
    ('cremoso','cortado','VIERNES','FEB'),
    ('azul','salado','VIERNES','OCT'),
    ('fresco','madurado','JUEVES','OCT'),
    ('hoja','cortado','MARTES','JUL'),
    ('fresco','cortado','MIERCOLES','JUL'),
    ('cremoso','prensado','LUNES','JUL'),
    ('pasta_hilada','coagulado','MIERCOLES','ABR'),
    ('azul','madurado','MIERCOLES','ABR'),
    ('pasta_hilada','salado','JUEVES','JUN');

insert into empleados (nombre, apellido, edad, idQueso) values
    ('Julio','Sanches',38,1),
    ('Miguel','Alvares',45,1),
    ('Pablo','Rodriguez',62,1),
    ('Julio','Valdez',44,1),
    ('Julio','Romero',36,1),
    ('Patricia','Rodriguez',50,1),
    ('Walter','Valdez',52,1),
    ('Sebastian','Rivadavia',31,1),
    ('Federico','Valdez',68,1);
