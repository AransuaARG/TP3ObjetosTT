package ar.org.centro8.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
